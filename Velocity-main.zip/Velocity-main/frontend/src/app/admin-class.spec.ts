import { AdminClass } from './admin-class';

describe('AdminClass', () => {
  it('should create an instance', () => {
    expect(new AdminClass()).toBeTruthy();
  });
});
